#configuration
CONFIG +=  cross_compile shared qpa no_mocdepend release qt_no_framework
host_build {
    QT_ARCH = x86_64
    QT_TARGET_ARCH = arm
} else {
    QT_ARCH = arm
    QMAKE_DEFAULT_LIBDIRS = /opt/gcc-linaro-5.2-2015.11-2-x86_64_arm-linux-gnueabihf/lib/gcc/arm-linux-gnueabihf/5.2.1 /opt/gcc-linaro-5.2-2015.11-2-x86_64_arm-linux-gnueabihf/lib/gcc/arm-linux-gnueabihf /opt/gcc-linaro-5.2-2015.11-2-x86_64_arm-linux-gnueabihf/lib/gcc /opt/gcc-linaro-5.2-2015.11-2-x86_64_arm-linux-gnueabihf/arm-linux-gnueabihf/lib /opt/gcc-linaro-5.2-2015.11-2-x86_64_arm-linux-gnueabihf/arm-linux-gnueabihf/libc/lib /opt/gcc-linaro-5.2-2015.11-2-x86_64_arm-linux-gnueabihf/arm-linux-gnueabihf/libc/usr/lib
    QMAKE_DEFAULT_INCDIRS = /opt/gcc-linaro-5.2-2015.11-2-x86_64_arm-linux-gnueabihf/arm-linux-gnueabihf/include/c++/5.2.1 /opt/gcc-linaro-5.2-2015.11-2-x86_64_arm-linux-gnueabihf/arm-linux-gnueabihf/include/c++/5.2.1/arm-linux-gnueabihf /opt/gcc-linaro-5.2-2015.11-2-x86_64_arm-linux-gnueabihf/arm-linux-gnueabihf/include/c++/5.2.1/backward /opt/gcc-linaro-5.2-2015.11-2-x86_64_arm-linux-gnueabihf/lib/gcc/arm-linux-gnueabihf/5.2.1/include /opt/gcc-linaro-5.2-2015.11-2-x86_64_arm-linux-gnueabihf/lib/gcc/arm-linux-gnueabihf/5.2.1/include-fixed /opt/gcc-linaro-5.2-2015.11-2-x86_64_arm-linux-gnueabihf/arm-linux-gnueabihf/include /opt/gcc-linaro-5.2-2015.11-2-x86_64_arm-linux-gnueabihf/arm-linux-gnueabihf/libc/usr/include
}
QT_CONFIG +=  minimal-config small-config medium-config large-config full-config no-pkg-config evdev linuxfb c++11 accessibility shared qpa reduce_exports clock-gettime clock-monotonic posix_fallocate mremap getaddrinfo ipv6ifname getifaddrs inotify eventfd png freetype harfbuzz zlib nis iconv dbus rpath concurrent audio-backend release

#versioning
QT_VERSION = 5.5.1
QT_MAJOR_VERSION = 5
QT_MINOR_VERSION = 5
QT_PATCH_VERSION = 1

#namespaces
QT_LIBINFIX = 
QT_NAMESPACE = 

QT_EDITION = OpenSource

QT_GCC_MAJOR_VERSION = 5
QT_GCC_MINOR_VERSION = 2
QT_GCC_PATCH_VERSION = 1
